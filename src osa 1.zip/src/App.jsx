import { useState } from 'react';
import Form from './components/Form';
import Search from './components/Search';

function App() {

  const [puzzles, setPuzzles] = useState([
    {
      name: "World Landmarks",
      brand: "Educa",
      pieces: "2000",
      picture: "/world-landmarks.jpg",
      status: "Not yet started",
    },
    {
      name: "Amazing Chameleons",
      brand: "Cherry Pazzi",
      pieces: "2000",
      picture: "/amazing-chameleons.jpg",
      status: "Completed",
    },
    {
      name: "Wolves in the Forest",
      brand: "Ravensburger",
      pieces: "1000",
      picture: "/wolves-in-the-forest.jpg",
      status: "Under construction",
    },
  ]);

  const statusSelectOptions = ["Wishlisted", "Not yet started", "Under construction", "Completed", "Sold"];

  return (
    <>
      <Form puzzles={puzzles} setPuzzles={setPuzzles} options={statusSelectOptions} />
      <h2>Puzzle library</h2>
      <Search puzzles={puzzles} />
    </>
  )
}

export default App
