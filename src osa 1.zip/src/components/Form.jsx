import { useEffect, useState } from 'react';
import PropTypes from 'prop-types';

function Form({ puzzles, setPuzzles, options }) {
  const [puzzle, setPuzzle] = useState({ name: '', brand: '', pieces: '', status: '', picture: '' });
  const [message, setMessage] = useState('');

  const inputChanged = (event) => {
    setPuzzle({ ...puzzle, [event.target.name]: event.target.value });
  }

  const lisaa = () => {
    if (puzzle.name == '' || puzzle.brand == '' || puzzle.pieces == '' || puzzle.status == '') {
      setMessage('Please insert the required data');
    } else {
      setPuzzle({ name: '', brand: '', pieces: '', status: '', picture: '' });
      setMessage('New puzzle successfully added!');
      setPuzzles([ puzzle, ...puzzles ]);
    }
  }

  useEffect(() => {
    const timeout = setTimeout(() => {setMessage('');}, 2000);
    return () => clearTimeout(timeout);
  });

  return (
    <>
      <h2>Add a puzzle</h2>
      <form>
        <label>Name*&nbsp;
          <input type='text' name='name' value={puzzle.name} onChange={inputChanged} />
        </label><br />
        <label>Brand*&nbsp;
          <input type='text' name='brand' value={puzzle.brand} onChange={inputChanged} />
        </label><br />
        <label>Number of pieces*&nbsp;
          <input type='number' min='2' name='pieces' value={puzzle.pieces} onChange={inputChanged} />
        </label><br />
        <label>Status*&nbsp;
          <select name='status' value={puzzle.status} onChange={inputChanged}>
            <option value="" disabled>Select</option>
            {options.map((option, index) => {
              return <option key={index} value={option}>{option}</option>})}
          </select>
        </label><br />
        <label>Upload a picture&nbsp;
          <input type="file" />
        </label><br />
        <p>*required data</p>
        <input type='button' value='Add' onClick={lisaa} />
      </form>
      <p style={{color: "red"}}>{message}</p>
    </>
  )
}

Form.propTypes = {
  puzzles: PropTypes.arrayOf(PropTypes.object),
  setPuzzles: PropTypes.func,
  options: PropTypes.array
}

export default Form;
