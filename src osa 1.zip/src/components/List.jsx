import PropTypes from 'prop-types';

function List({ puzzles }) {
    return (
        <table style={{border: '1px solid #ddd', borderCollapse: 'collapse'}}>
            <thead>
                <tr style={{borderBottom: '1px solid #ddd'}}>
                    <th style={{width: '200px'}}></th>
                    <th style={{width: '250px'}}>Name</th>
                    <th style={{width: '200px'}}>Brand</th>
                    <th style={{width: '150px', textAlign: 'left'}}>Number of pieces</th>
                    <th style={{width: '150px'}}>Status</th>
                </tr>
            </thead>
            <tbody>
                {puzzles.map((puzzle, index) => {
                    return (
                    <tr key={index} style={{borderBottom: '1px solid #ddd'}}>
                        <td><img src={puzzle.picture} alt='Picture' onError={(e) => {e.target.onerror=null; e.target.src="./pieces.png"; e.target.alt="No picture"}} height='100px' /></td>
                        <td>{puzzle.name}</td>
                        <td>{puzzle.brand}</td>
                        <td>{puzzle.pieces}</td>
                        <td>{puzzle.status}</td>
                    </tr>
                    );})
                }
            </tbody>
        </table>
    )
}

List.propTypes = {
    puzzles: PropTypes.arrayOf(PropTypes.object),
}

export default List;