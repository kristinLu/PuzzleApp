import PropTypes from 'prop-types';
import { DataGrid } from '@mui/x-data-grid';
import { Box } from '@mui/material';

function List({ puzzles }) {
    const columns = [
        {
            field: 'image_url',
            headerName: 'Image',
            width: 200,
            renderCell: (params) => (
                <Box style={{ maxHeight: '500px', overflow: 'hidden' }}>
                    <img alt='Image' src={params.row.image_url} style={{ maxWidth: '100%', height: 'auto' }} />
                </Box>
            ),
        },
        {
            field: 'title',
            headerName: 'Title',
            width: 150,
            editable: true,
        },
        {
            field: 'brand',
            headerName: 'Brand',
            width: 150,
            editable: true,
        },
        {
            field: 'pieces',
            headerName: 'Number of pieces',
            type: 'number',
            width: 150,
            editable: true,
        }
    ];

    const rows = puzzles.map(puzzle => ({
        id: puzzle.id,
        image_url: puzzle.image_url,
        title: puzzle.title,
        brand: puzzle.brand,
        pieces: puzzle.pieces,
    }));

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', width: '100%', marginTop: 5 }}>
            <Box style={{ width: '80%' }}>
            <DataGrid
                autoHeight
                rows={rows}
                columns={columns}
                
                getRowHeight={(params) => Math.min(params.rowHeight || 150, 150)}
                initialState={{
                    pagination: {
                        paginationModel: {
                            pageSize: 3,
                        },
                    },
                }}
                pageSizeOptions={[3]}
                disableRowSelectionOnClick
            />
            </Box>
        </Box>
    )
}

List.propTypes = {
    puzzles: PropTypes.arrayOf(PropTypes.object),
}

export default List;