import { useState } from "react";
import PropTypes from 'prop-types';
import { red } from '@mui/material/colors';
import { styled } from '@mui/material/styles';
import ExtensionIcon from '@mui/icons-material/Extension';
import FavoriteIcon from '@mui/icons-material/Favorite';
import ShareIcon from '@mui/icons-material/Share';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {
    Avatar,
    Box,
    Card,
    CardActions,
    CardHeader,
    CardContent,
    CardMedia,
    Collapse,
    Grid,
    IconButton,
    Typography
} from '@mui/material';

const ExpandMore = styled((props) => {
    const { ...other } = props;
    return <IconButton {...other} />;
})(({ theme, expand }) => ({
    transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
    marginLeft: 'auto',
    transition: theme.transitions.create('transform', {
        duration: theme.transitions.duration.shortest,
    }),
}));

const StyledCardMedia = styled(CardMedia)({
    maxWidth: '100%', // Ensure the image fits within the container
    maxHeight: '100%', // Ensure the image fits within the container
    width: 'auto', // Automatically adjust the width to maintain aspect ratio
    height: '50vh', // Automatically adjust the height to maintain aspect ratio
    display: 'flex', // Use flexbox layout
    justifyContent: 'center', // Center the content horizontally
    alignItems: 'center', // Center the content vertically
});

function Results({ puzzles, message }) {
    const [expanded, setExpanded] = useState(false);

    const handleExpandClick = () => {
        setExpanded(!expanded);
    };

    if (puzzles === null) { return <Typography>{message}</Typography> }

    return (
        <Box sx={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {puzzles.map(puzzle => {
                return (
                    <Grid item key={puzzle.barcode_number} sx={{ width: '80%', minHeight: 400 }}>
                        <Card sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: '#00bfa5', borderStyle: 'solid', borderRadius: 5 }}>
                            <CardHeader
                                avatar={<Avatar sx={{ bgcolor: red[500] }} aria-label="puzzle"><ExtensionIcon /></Avatar>}
                                title={puzzle.title}
                                subheader={`EAN: ${puzzle.barcode_number}`} />
                            {puzzle.images[1] ?
                                <StyledCardMedia component='img' image={puzzle.images[1]}></StyledCardMedia>
                                :
                                <Typography sx={{ height: 300, textAlign: 'center' }}>Ei kuvaa</Typography>
                            }
                            <CardActions disableSpacing>
                                <IconButton aria-label="add to favorites">
                                    <FavoriteIcon />
                                </IconButton>
                                <IconButton aria-label="share">
                                    <ShareIcon />
                                </IconButton>
                                <ExpandMore
                                    expand={expanded}
                                    onClick={handleExpandClick}
                                    aria-expanded={expanded}
                                    aria-label="show more"
                                >
                                    <ExpandMoreIcon />
                                </ExpandMore>
                            </CardActions>
                            <Collapse in={expanded} timeout="auto" unmountOnExit>
                                <CardContent>
                                    <Typography>Title:</Typography>
                                    <Typography>{puzzle.title}</Typography>
                                    <Typography>Brand:</Typography>
                                    <Typography>{puzzle.brand}</Typography>
                                    <Typography>EAN: {puzzle.barcode_number}</Typography>
                                    <Typography paragraph>Description:</Typography>
                                    <Typography paragraph>{puzzle.description}</Typography>
                                </CardContent>
                            </Collapse>
                        </Card>
                    </Grid>
                )
            })
            }
        </Box>
    )
}

Results.propTypes = {
    puzzles: PropTypes.arrayOf(PropTypes.object),
    message: PropTypes.string
}

export default Results;