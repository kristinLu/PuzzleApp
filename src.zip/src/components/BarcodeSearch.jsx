import { useState } from "react";
import Results from './Results';
import { Box, Button, TextField} from '@mui/material';

function Search() {
    const [keyword, setKeyword] = useState('');
    const [resultsToBeShown, setResultsToBeShown] = useState([]);
    const [message, setMessage] = useState('');

    const inputChanged = (event) => {
        setKeyword(event.target.value.toLowerCase().trim());
      }

    const findPuzzles = async () => {
        //`https://wry-grizzly-donkey.glitch.me/https://api.barcodelookup.com/v3/products?barcode=5903728750101&formatted=y&key=urq17ng01nbrg4qnmxa1dz8sxheb1r`
        const proxyurl = 'https://wry-grizzly-donkey.glitch.me/';
        const apikey = 'urq17ng01nbrg4qnmxa1dz8sxheb1r';
        const url = `${proxyurl}https://api.barcodelookup.com/v3/products?barcode=${keyword}&formatted=y&key=${apikey}`;
        if (keyword !== '') {
          try {
            const response = await fetch(url);
            console.log('RESPONSE ', response);
            try {
                const json = await response.json();
                console.log('JSON ', json);
                console.log('PRODUCTS ', json.products);
                if (json.products === null) {
                    setMessage('Tuloksia ei löytynyt');
                }
                setResultsToBeShown(json.products);
                setMessage(json.products[0].title)
              } catch (error) {
                console.error('Error parsing JSON:', error);
              }
          } catch (error) {
            setMessage('Jokin meni pieleen');
          }
        } else {
          setMessage('Syötä viivakoodi');
        }
      }

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', margin: 10 }}>
            <TextField fullWidth margin='normal' type='number' label='Search by barcode' name='barcode' value={keyword} onChange={inputChanged} />
            <Button sx={{ margin: 1 }} variant='outlined' onClick={findPuzzles}>Search</Button>
            <Results puzzles={resultsToBeShown} message={message} />
        </Box>
    )
}

export default Search;