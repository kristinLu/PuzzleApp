import { Box, Typography } from '@mui/material';

function Home() {

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', margin: 10 }}>
            <Typography variant='h4'>Welcome!</Typography>
            <Typography paragraph>I am homepage. I am not yet ready, neither are my cousins but we are working hard to get everything up and running</Typography>
        </Box>
    );
}

export default Home;