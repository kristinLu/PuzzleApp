import { useEffect, useState } from "react";
import PropTypes from 'prop-types';
import List from './List';

function Search({ puzzles }) {
    const [keyword, setKeyword] = useState('');
    const [resultsToBeShown, setResultsToBeShown] = useState(puzzles);

    useEffect(() => {setResultsToBeShown(puzzles)}, [puzzles]);

    const findPuzzles = () => {
        if (keyword == '') {
            setResultsToBeShown(puzzles);
        } else {
            let filteredList = puzzles.filter(puzzle => puzzle.name.toLowerCase().includes(keyword) || puzzle.brand.toLowerCase().includes(keyword));
            setResultsToBeShown(filteredList);
        }
    }

    return (
        <>
            <input 
                type='text' 
                placeholder='Search by keyword'
                value={keyword}
                onChange={event => setKeyword(event.target.value.toLowerCase().trim())} />
            <input 
                type='button'
                value='Search' 
                onClick={findPuzzles}/>
            <List puzzles={resultsToBeShown} />
        </>
    )
}

Search.propTypes = {
    puzzles: PropTypes.arrayOf(PropTypes.object),
}

export default Search;