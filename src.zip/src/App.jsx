import { Link, BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { AppBar, CssBaseline, Tab, Tabs, ThemeProvider, createTheme } from '@mui/material';
import ExtensionIcon from '@mui/icons-material/Extension';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import { useState } from 'react';
import Form from './components/Form';
import Home from './components/Home';
import List from './components/List';
import BarcodeSearch from './components/BarcodeSearch';


const theme = createTheme({
  palette: {
    primary: { main: '#00bfa5', contrastText: '#FFFFFF' },
    secondary: { main: '#6d4c41', contrastText: '#FFFFFF' },
    text: { primary: '#00897b', secondary: '#7c4dff' },
  },
  typography: {
    fontFamily: "'Raleway'",
    h4: {
      fontFamily: "'Audiowide'",
      lineHeight: 2.6,
      color: "#7c4dff"
    },
    button: {
      fontFamily: "'Audiowide'",
    },
  },
});

function App() {

  const [puzzles, setPuzzles] = useState([
    {
      id: 1,
      title: "World Landmarks",
      brand: "Educa",
      ean: null,
      pieces: 2000,
      image: "/world-landmarks.jpg",
      image_url: 'https://www.educaborras.com/wp-content/uploads/17129_01_high.jpg',
      ownership_status: "Owned",
      completion_status: "Completed",
      description: null
    },
    {
      id: 2,
      title: "Amazing Chameleons",
      brand: "Cherry Pazzi",
      ean: null,
      pieces: 2000,
      image: "/amazing-chameleons.jpg",
      image_url: 'https://static.alipson.fr/m244/p459244/p2_FULL.jpg',
      ownership_status: "Wishlisted",
      completion_status: null,
      description: null
    },
    {
      id: 3,
      title: "Wolves in the Forest",
      brand: "Ravensburger",
      ean: null,
      pieces: 1000,
      image: "/wolves-in-the-forest.jpg",
      image_url: 'https://www.ravensburger.us/produktseiten/1024/15987.jpg',
      ownership_status: "Owned",
      completion_status: "Under construction",
      description: null
    },
  ]);

  //const ownershipStatusSelectOptions = ["Owned", "Wishlisted", "Previously owned"];
  const completionStatusSelectOptions = ["Not yet started", "Under construction", "Completed", "Abandoned"];

  const [value, setValue] = useState(0);

  const handleChange = (e, val) => { setValue(val) }

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <AppBar position='static'>
          <Tabs textColor='inherit' variant='fullWidth' value={value} onChange={handleChange}>
            <Tab label='HOME' icon={<ExtensionIcon />} component={Link} to='/' />
            <Tab label='BARCODE SEARCH' icon={<SearchRoundedIcon />} component={Link} to='barcodesearch' />
            <Tab label='MY COLLECTION' icon={<ExtensionIcon />} component={Link} to='collection' />
            <Tab label='WISHLIST' icon={<ExtensionIcon />} component={Link} to='wishlist' />
            <Tab label='ADD' icon={<ExtensionIcon />} component={Link} to='add' />
          </Tabs>
        </ AppBar>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='barcodesearch' element={<BarcodeSearch />} />
          <Route path='collection' element={<List puzzles={puzzles} />} />
          <Route path='wishlist' element={<List puzzles={puzzles} />} />
          <Route path='add' element={<Form puzzles={puzzles} setPuzzles={setPuzzles} completion={completionStatusSelectOptions} />} />
          <Route path='*' element={<Home />} />
        </Routes>
      </Router>
    </ThemeProvider>
  )
}

export default App
